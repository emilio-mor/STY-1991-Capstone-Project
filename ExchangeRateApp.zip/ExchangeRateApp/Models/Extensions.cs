namespace ExchangeRateApp.Models;

public static class CryptoRateExtensions
{
    public static string Color20(this CryptoRate c) =>
        c.Color.Length == 7 ? c.Color + "33" : c.Color;
}
