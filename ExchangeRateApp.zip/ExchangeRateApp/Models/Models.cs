using System.ComponentModel.DataAnnotations;

namespace ExchangeRateApp.Models;

// ─── Auth & User ─────────────────────────────────────────────────────────────

public class User
{
    public int Id { get; set; }
    [Required, MaxLength(50)] public string Username { get; set; } = "";
    [Required, MaxLength(100)] public string Email { get; set; } = "";
    [Required] public string PasswordHash { get; set; } = "";
    [MaxLength(100)] public string FullName { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? LastLogin { get; set; }
    public ICollection<FavoriteCurrency> FavoriteCurrencies { get; set; } = new List<FavoriteCurrency>();
    public ICollection<NotificationAlert> NotificationAlerts { get; set; } = new List<NotificationAlert>();
}

public class RegisterViewModel
{
    [Required(ErrorMessage = "Username is required")]
    [MinLength(3, ErrorMessage = "Username must be at least 3 characters")]
    [MaxLength(50)]
    public string Username { get; set; } = "";

    [Required(ErrorMessage = "Full name is required")]
    [MaxLength(100)]
    public string FullName { get; set; } = "";

    [Required(ErrorMessage = "Email is required")]
    [EmailAddress(ErrorMessage = "Invalid email format")]
    public string Email { get; set; } = "";

    [Required(ErrorMessage = "Password is required")]
    [MinLength(6, ErrorMessage = "Password must be at least 6 characters")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";

    [Required(ErrorMessage = "Please confirm your password")]
    [DataType(DataType.Password)]
    [Compare("Password", ErrorMessage = "Passwords do not match")]
    public string ConfirmPassword { get; set; } = "";
}

public class LoginViewModel
{
    [Required(ErrorMessage = "Email or username is required")]
    public string EmailOrUsername { get; set; } = "";

    [Required(ErrorMessage = "Password is required")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";

    public bool RememberMe { get; set; }
}

// ─── Exchange Rate ────────────────────────────────────────────────────────────

public class ExchangeRatePair
{
    public string BaseCurrency { get; set; } = "";
    public string TargetCurrency { get; set; } = "";
    public double Rate { get; set; }
    public double ChangePercent { get; set; }
    public double ChangeValue { get; set; }
    public string BaseName { get; set; } = "";
    public string TargetName { get; set; } = "";
    public string BaseFlag { get; set; } = "";
    public string TargetFlag { get; set; } = "";
    public DateTime LastUpdated { get; set; } = DateTime.UtcNow;
}

public class CryptoRate
{
    public string Symbol { get; set; } = "";
    public string Name { get; set; } = "";
    public double PriceUsd { get; set; }
    public double ChangePercent24h { get; set; }
    public double MarketCap { get; set; }
    public double Volume24h { get; set; }
    public string Icon { get; set; } = "";
    public string Color { get; set; } = "";
}

public class ConversionResult
{
    public string FromCurrency { get; set; } = "";
    public string ToCurrency { get; set; } = "";
    public string FromName { get; set; } = "";
    public string ToName { get; set; } = "";
    public string FromFlag { get; set; } = "";
    public string ToFlag { get; set; } = "";
    public double Amount { get; set; }
    public double Result { get; set; }
    public double Rate { get; set; }
    public double InverseRate { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}

public class ConverterViewModel
{
    public List<CurrencyInfo> AllCurrencies { get; set; } = new();
    public ConversionResult? Result { get; set; }
    public string FromCurrency { get; set; } = "USD";
    public string ToCurrency { get; set; } = "EUR";
    public double Amount { get; set; } = 1;
}

// ─── Favorites ───────────────────────────────────────────────────────────────

public class FavoriteCurrency
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public User? User { get; set; }
    [MaxLength(10)] public string CurrencyCode { get; set; } = "";
    [MaxLength(100)] public string CurrencyName { get; set; } = "";
    [MaxLength(10)] public string Flag { get; set; } = "";
    public bool IsCrypto { get; set; }
    public DateTime AddedAt { get; set; } = DateTime.UtcNow;
}

// ─── Notifications ───────────────────────────────────────────────────────────

public class NotificationAlert
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public User? User { get; set; }
    [MaxLength(10)] public string BaseCurrency { get; set; } = "";
    [MaxLength(10)] public string TargetCurrency { get; set; } = "";
    public double TargetRate { get; set; }
    public AlertCondition Condition { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsTriggered { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? TriggeredAt { get; set; }
}

public enum AlertCondition { Above, Below }

public class NotificationLog
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string Message { get; set; } = "";
    public string CurrencyPair { get; set; } = "";
    public bool IsRead { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class CreateAlertViewModel
{
    [Required] public string BaseCurrency { get; set; } = "USD";
    [Required] public string TargetCurrency { get; set; } = "EUR";
    [Required, Range(0.0001, 10000000)] public double TargetRate { get; set; }
    [Required] public AlertCondition Condition { get; set; }
}

// ─── Trends ──────────────────────────────────────────────────────────────────

public class RateSnapshot
{
    public int Id { get; set; }
    [MaxLength(10)] public string BaseCurrency { get; set; } = "";
    [MaxLength(10)] public string TargetCurrency { get; set; } = "";
    public double Rate { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}

public class TrendData
{
    public string Pair { get; set; } = "";
    public string BaseName { get; set; } = "";
    public string TargetName { get; set; } = "";
    public string BaseFlag { get; set; } = "";
    public string TargetFlag { get; set; } = "";
    public double CurrentRate { get; set; }
    public double ChangePercent { get; set; }
    public double High { get; set; }
    public double Low { get; set; }
    public List<RatePoint> History { get; set; } = new();
}

public class RatePoint
{
    public DateTime Date { get; set; }
    public double Rate { get; set; }
}

// ─── Currency Info ────────────────────────────────────────────────────────────

public class CurrencyInfo
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Flag { get; set; } = "";
    public string Symbol { get; set; } = "";
}

// ─── Dashboard ───────────────────────────────────────────────────────────────

public class DashboardViewModel
{
    public List<ExchangeRatePair> TopForex { get; set; } = new();
    public List<CryptoRate> TopCrypto { get; set; } = new();
    public List<FavoriteCurrency> Favorites { get; set; } = new();
    public int UnreadNotifications { get; set; }
    public DateTime LastUpdated { get; set; } = DateTime.UtcNow;
}

public class NotificationsViewModel
{
    public List<NotificationAlert> Alerts { get; set; } = new();
    public List<NotificationLog> Logs { get; set; } = new();
    public List<CurrencyInfo> AllCurrencies { get; set; } = new();
    public CreateAlertViewModel NewAlert { get; set; } = new();
    public int UnreadCount { get; set; }
}
